import React from "react";
import "./Header.css";

export const Header = () => {
  return (
    <>
      <div class="header">
        <div class="head">
          <h1>Inventory Valuator</h1>
        </div>
        <p class="desc"><span className="alr">*</span>based on Weighted Average Cost (WAC) method.</p>
      </div>
    </>
  );
};
