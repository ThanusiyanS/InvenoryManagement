import React, { useContext, useEffect } from "react";
import { Transaction } from "./Transaction";

import { GlobalContext } from "../context/GlobalState";
import "./TransactionList.css";

export const TransactionList = () => {
  const { transactions, getTransactions } = useContext(GlobalContext);

  useEffect(() => {
    getTransactions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <div className="trnshs">
        <h3>Transaction History</h3>
        <p>prices are menioned in Rupees (Rs.)</p>
        <div>
          <ul className="list">
            <li>
              <span>Date</span>
              <span>Quantity</span>
              <span>Unit Price</span>
              <span>Value</span>
              <span>Quantity</span>
              <span>Unit Price</span>
              <span>Value</span>
            </li>
            <div className="trnslist">
              {transactions.map((transaction) => (
                <Transaction key={transaction._id} transaction={transaction} />
              ))}
            </div>
          </ul>
        </div>
      </div>
    </>
  );
};
